# OrangeHRM Automation (Selenium + Java + TestNG + POM)

This project automates OrangeHRM login, updating contact details, changing password, and logout workflows.

## Run Tests
```bash
mvn test
```
